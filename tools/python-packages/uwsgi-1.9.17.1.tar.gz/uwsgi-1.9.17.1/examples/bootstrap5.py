import uwsgi

print uwsgi.extract("data://0")
